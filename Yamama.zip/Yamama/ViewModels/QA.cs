﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Yamama.ViewModels
{
    public class QA
    {
        public int QID { get; set; }
        public int AID { get; set; }
    }
}
