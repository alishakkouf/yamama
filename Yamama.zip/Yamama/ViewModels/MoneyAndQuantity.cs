﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Yamama.ViewModels
{
    public class MoneyAndQuantity
    {
        public Double Money { get; set; }
        public Double Quantity { get; set; }
    }
}
