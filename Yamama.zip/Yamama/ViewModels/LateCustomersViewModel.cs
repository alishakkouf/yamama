﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Yamama.ViewModels
{
    public class LateCustomersViewModel
    {
        public List<string> factoriesNames { get; set; }
        public List<string> projectsNames { get; set; }
    }
}
