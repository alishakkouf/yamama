﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Yamama.ViewModels
{
    public class InvoiceAndQuantity
    {
        public int CartInvoiceId { get; set; }
        public Double Qty { get; set; }
    }
}
